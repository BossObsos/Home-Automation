package com.example.ihopefianl;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    ImageButton bathroom,bedroom,kitchen,corridor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bathroom = (ImageButton) findViewById(R.id.bathroom);
        bathroom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentbathroom = new Intent(MainActivity.this, bathroom.class);
                startActivity(intentbathroom);
            }
        });

        bedroom = (ImageButton) findViewById(R.id.bedroom);
        bedroom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentbedroom = new Intent(MainActivity.this, bedroom.class);
                startActivity(intentbedroom);
            }
        });

        kitchen = (ImageButton) (ImageButton) findViewById(R.id.kitchen);
        kitchen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentkitchen = new Intent(MainActivity.this, kitchen.class);
                startActivity(intentkitchen);
            }
        });
    }

}
